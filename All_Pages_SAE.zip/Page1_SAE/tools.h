#ifndef TOOLS_H_INCLUDED
#define TOOLS_H_INCLUDED
#include <ncurses.h>
#include <string.h>
#include <time.h>

#define LIGNES 2
#define COLONNES 6

#define BOX2_HEIGHT 5
#define BOX2_WIDTH 27
#define BOX2_Y 1
#define BOX2_X 52

#define BOX3_HEIGHT 5
#define BOX3_WIDTH 2
#define BOX3_Y 18
#define BOX3_X 1

//Le JEU de CARTES

void initialiserCartes(char cartes[LIGNES * COLONNES]);

void melangerCartes(char cartes[LIGNES * COLONNES]);

void afficherCarte(int indice, char carte, bool carteVisible, bool estSelectionnee);

void afficherCartes(char cartes[LIGNES * COLONNES], bool cartesVisibles[LIGNES * COLONNES], int carteSelectionnee);

void afficherTimer(time_t debutTimer);

char autoplayer();

//Création des box pour l'affichage

void drawBox(WINDOW *box, int height, int width, int starty, int startx, const char *title, const char *content);

void drawChrono(WINDOW *box, int height, int width, int starty, int startx);


#endif // TOOLS_H_INCLUDED
